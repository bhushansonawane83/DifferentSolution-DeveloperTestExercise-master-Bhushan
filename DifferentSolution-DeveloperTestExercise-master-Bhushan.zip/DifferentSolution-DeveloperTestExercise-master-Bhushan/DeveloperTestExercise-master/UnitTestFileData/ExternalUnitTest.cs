﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using BL;
using ThirdPartyTools;
namespace UnitTestFileData
{
    class ExternalUnitTest
    {
        [TestMethod]
        public void TestMethodThirdVersion()
        {
            var MoqThirdObj = new Mock<ThirdPartyTools.FileDetails>();
            MoqThirdObj.Setup(x => x.Version(It.IsAny<string>())).Returns("4.4.4");
            ExternalGetway.ExternalGateWay objexternal = new ExternalGetway.ExternalGateWay(MoqThirdObj.Object);
            var strsize = objexternal.DisplayVersion("-v", "C:/CE.txt");
            Assert.IsNotNull(strsize);
            Assert.AreEqual(strsize, "1515");
        }

        [TestMethod]
        public void TestMethodThirdSize()
        {
            var MoqThirdObj = new Mock<ThirdPartyTools.FileDetails>();
            MoqThirdObj.Setup(x => x.Size(It.IsAny<string>())).Returns(1212);
            ExternalGetway.ExternalGateWay objexternal = new ExternalGetway.ExternalGateWay(MoqThirdObj.Object);
            var strsize = objexternal.DisplaySize("-s", "C:/CE.txt");
            Assert.IsNotNull(strsize);
            Assert.AreEqual(strsize, "1515");
        }
    }
}
