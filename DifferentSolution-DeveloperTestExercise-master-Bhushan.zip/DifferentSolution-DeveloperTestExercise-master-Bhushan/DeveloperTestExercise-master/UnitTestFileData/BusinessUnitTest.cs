﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using BL;
using ThirdPartyTools;
namespace UnitTestFileData
{
    [TestClass]
    public class BusinessUnitTest
    {
        [TestMethod]
        public void TestMethodBLVersion()
        {
            var MoqExternalObj = new Mock<ExternalGetway.ExternalGateWay>(new FileDetails());
            MoqExternalObj.Setup(x => x.DisplayVersion(It.IsAny<string>(), It.IsAny<string>())).Returns("4.4.4");
            Business objbusines = new Business(MoqExternalObj.Object);
            var strversion = objbusines.DisplayVersion("-v","C:/CE.txt");
            Assert.IsNotNull(strversion);
            Assert.AreEqual(strversion, "4.4.4");
        }
        [TestMethod]
        public void TestMethodBLSize()
        {
            var MoqExternalObj = new Mock<ExternalGetway.ExternalGateWay>(new FileDetails() );
            MoqExternalObj.Setup(x => x.DisplaySize(It.IsAny<string>(), It.IsAny<string>())).Returns(1212);
            Business objbusines = new Business(MoqExternalObj.Object);
            var strsize = objbusines.DisplaySize("-v", "C:/CE.txt");
            Assert.IsNotNull(strsize);
            Assert.AreEqual(strsize, "1515");
        }

        
    }
}
