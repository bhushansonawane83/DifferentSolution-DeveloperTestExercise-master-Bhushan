﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
    public interface IBL
    {
        string DisplayVersion(string strVersion, string strFileName);
        int DisplaySize(string strSize, string strFileName);
    }
}
