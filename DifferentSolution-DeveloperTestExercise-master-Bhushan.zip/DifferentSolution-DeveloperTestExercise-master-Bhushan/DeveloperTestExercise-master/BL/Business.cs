﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExternalGetway;
namespace BL
{
    public class Business : IBL
    {
        private IExternalGateWay _iel;

        public Business(IExternalGateWay iel)
        {
            _iel = iel;
        }
        public int DisplaySize(string strSize, string strFileName)
        {
            try
            {
                return _iel.DisplaySize(strSize, strFileName);
                
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public string DisplayVersion(string strVersion, string strFileName)
        {
            try
            {
                return _iel.DisplayVersion(strVersion, strFileName);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
