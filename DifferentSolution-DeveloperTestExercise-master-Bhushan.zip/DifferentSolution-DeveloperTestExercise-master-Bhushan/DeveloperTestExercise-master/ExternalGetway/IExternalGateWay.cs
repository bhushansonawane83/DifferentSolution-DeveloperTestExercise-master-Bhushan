﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalGetway
{
    public interface IExternalGateWay
    {
        int DisplaySize(string strSize, string strFileName);
        string DisplayVersion(string strVersion, string strFileName);
    }
}
