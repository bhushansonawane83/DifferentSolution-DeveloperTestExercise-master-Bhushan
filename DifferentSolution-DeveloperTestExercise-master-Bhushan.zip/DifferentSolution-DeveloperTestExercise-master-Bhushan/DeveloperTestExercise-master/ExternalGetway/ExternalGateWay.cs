﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyTools;
namespace ExternalGetway
{
    public class ExternalGateWay : IExternalGateWay
    {
        FileDetails _objfile;
        public ExternalGateWay(FileDetails objfile)
        {
            _objfile = objfile;
        }
      
        public virtual int DisplaySize(string strSize, string strFileName)
        {
            try
            {
                return _objfile.Size(strFileName);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    
        public virtual string  DisplayVersion(string strVersion, string strFileName)
        {
            try
            {
                return _objfile.Version(strFileName);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        
        }
    }
}
