﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;
using BL;// new
using Unity;
using ExternalGetway;
namespace FileData
{
    public class Program
    {

        public static void Main(string[] args)
        {
            {

                try
                {
                    string strVersionOrSize = string.Empty;
                    string strFileName = string.Empty;

                    IUnityContainer obj = new UnityContainer();
                    obj.RegisterType<IBL, Business>();
                    obj.RegisterType<IExternalGateWay, ExternalGetway.ExternalGateWay>();
                    UI objUI = obj.Resolve<UI>();
                                       
                   // UI objUI = new UI(new Business(new ExternalGetway.ExternalGateWay(new FileDetails())));
                    if (args.Length == 0)
                    {
                        Console.WriteLine("No arguments were entered");
                        Console.ReadLine();
                    }
                    else
                    {
                        strVersionOrSize = args[0];
                        strFileName = args[1];
                        objUI.GetDetailsVersionAndSize(strVersionOrSize, strFileName);

                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error " + ex.Message.ToString());
                    Console.ReadLine();
                }

            }
        }


    }
}
