﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BL;
namespace FileData
{
    public class UI : IUI
    {
        private IBL _ibl;

        public UI(IBL ibl)
        {
            _ibl = ibl;
        }

        public void GetDetailsVersionAndSize(string strSizeAndVersion, string strFileName)
        {
            try
            {
                Console.WriteLine("Arguments Passed by the Programmer:" + strSizeAndVersion + " " + strFileName);
                ArrayList strArryListVersion = VersionValues();
                ArrayList strArryListSize = SizeValues();

                if (strArryListVersion.Contains(strSizeAndVersion))
                {
                    Console.WriteLine(DisplayVersion(strSizeAndVersion, strFileName));
                    Console.ReadLine();
                }
                if (strArryListSize.Contains(strSizeAndVersion))
                {
                    Console.WriteLine(DisplaySize(strSizeAndVersion, strFileName));
                    Console.ReadLine();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int DisplaySize(string strSize, string strFileName)
        {
            return _ibl.DisplaySize(strSize, strFileName);

        }

        public string DisplayVersion(string strVersion, string strFileName)
        {
            return _ibl.DisplayVersion(strVersion, strFileName);
        }
        public ArrayList VersionValues()
        {
            ArrayList objArryListVersion = new ArrayList();
            objArryListVersion.Add("v");
            objArryListVersion.Add("-v");
            objArryListVersion.Add("--v");
            objArryListVersion.Add("--version");
            return objArryListVersion;
        }

        public ArrayList SizeValues()
        {
            ArrayList objArryListSize = new ArrayList();
            objArryListSize.Add("s");
            objArryListSize.Add("-s");
            objArryListSize.Add("--s");
            objArryListSize.Add("--size");
            return objArryListSize;
        }
    }
}
